import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bugrepro.redact import redact


def test_redact_anthropic_key():
    text = "export ANTHROPIC_API_KEY=sk-ant-api03-abc123DEF456ghi789JKL"
    out = redact(text)
    assert "sk-ant-api03-abc123DEF456ghi789JKL" not in out
    assert "[REDACTED]" in out


def test_redact_github_token():
    text = "Auth failed with token ghp_1234567890abcdefghij1234567890abcd"
    out = redact(text)
    assert "ghp_1234567890abcdefghij1234567890abcd" not in out


def test_redact_aws_key():
    text = "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
    out = redact(text)
    assert "AKIAIOSFODNN7EXAMPLE" not in out


def test_redact_generic_key_value():
    text = 'config = {"api_key": "supersecretvalue123", "debug": true}'
    out = redact(text)
    assert "supersecretvalue123" not in out
    assert "debug" in out  # unrelated fields untouched


def test_redact_bearer_token():
    text = "Authorization: Bearer abcdef1234567890.xyz"
    out = redact(text)
    assert "abcdef1234567890.xyz" not in out


def test_redact_leaves_normal_text_untouched():
    text = "AssertionError: expected 5, got -1\nTraceback (most recent call last):"
    assert redact(text) == text


def test_redact_empty_string():
    assert redact("") == ""


def test_redact_none_safe():
    assert redact(None) is None

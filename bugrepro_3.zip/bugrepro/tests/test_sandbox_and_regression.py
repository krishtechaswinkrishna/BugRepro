import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bugrepro.models import FixSuggestion, RepoContext
from bugrepro.regression import apply_diff, make_scratch_copy, run_regression_test
from bugrepro.sandbox import (
    DockerSandbox, SandboxUnavailableError, SubprocessSandbox, docker_available,
    get_sandbox, image_for_language,
)


def _init_git_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-q"], cwd=path, check=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=path, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=path, check=True)
    subprocess.run(["git", "add", "-A"], cwd=path, check=True)
    subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=path, check=True)


# ---------------------------------------------------------------------------
# sandbox.py
# ---------------------------------------------------------------------------

def test_subprocess_sandbox_runs_command():
    sandbox = SubprocessSandbox()
    with tempfile.TemporaryDirectory() as tmp:
        result = sandbox.run(Path(tmp), "echo hello", timeout=10)
    assert result.returncode == 0
    assert "hello" in result.stdout
    assert result.backend == "subprocess"


def test_subprocess_sandbox_captures_nonzero_exit():
    sandbox = SubprocessSandbox()
    with tempfile.TemporaryDirectory() as tmp:
        result = sandbox.run(Path(tmp), "exit 3", timeout=10)
    assert result.returncode == 3
    assert result.backend == "subprocess"


def test_subprocess_sandbox_times_out():
    sandbox = SubprocessSandbox()
    with tempfile.TemporaryDirectory() as tmp:
        result = sandbox.run(Path(tmp), "sleep 5", timeout=1)
    assert result.returncode == -1
    assert "TIMEOUT" in result.stderr


def test_image_for_language():
    assert image_for_language("python") == "python:3.11.9-slim"
    assert image_for_language("node") == "node:20.15.1-slim"
    assert image_for_language(None) == "python:3.11.9-slim"  # default
    assert image_for_language("some_unknown_lang") == "python:3.11.9-slim"  # default


def test_get_sandbox_fails_closed_when_docker_unavailable_and_no_opt_in():
    # Fail-closed by default: if Docker isn't available, get_sandbox() must
    # refuse to silently hand back an unsandboxed subprocess backend.
    if docker_available():
        sandbox = get_sandbox(prefer_docker=True)
        assert sandbox.name == "docker"
    else:
        with pytest.raises(SandboxUnavailableError):
            get_sandbox(prefer_docker=True)


def test_get_sandbox_no_docker_flag_requires_explicit_fallback_opt_in():
    # --no-docker alone must NOT be enough to get an unsandboxed subprocess;
    # allow_unsandboxed_fallback must also be explicitly set.
    with pytest.raises(SandboxUnavailableError):
        get_sandbox(prefer_docker=False, allow_unsandboxed_fallback=False)

    sandbox = get_sandbox(prefer_docker=False, allow_unsandboxed_fallback=True)
    assert sandbox.name == "subprocess"


def test_docker_sandbox_network_flag_present_in_command():
    # We don't run this (Docker isn't installed here), but we can verify the
    # command construction includes --network none by default without
    # actually invoking Docker, by checking the class default.
    sandbox = DockerSandbox()
    assert sandbox.allow_network is False
    sandbox2 = DockerSandbox(allow_network=True)
    assert sandbox2.allow_network is True


def test_docker_sandbox_hardening_flags_in_run_command(monkeypatch):
    """Verify --read-only, --cap-drop=ALL, --security-opt no-new-privileges,
    and --rm are actually present in the constructed docker command, by
    intercepting subprocess.run instead of requiring a real Docker daemon."""
    captured_cmd = {}

    def fake_run(cmd, **kwargs):
        captured_cmd["cmd"] = cmd
        class FakeResult:
            returncode = 0
            stdout = ""
            stderr = ""
        return FakeResult()

    import bugrepro.sandbox as sandbox_module
    monkeypatch.setattr(sandbox_module.subprocess, "run", fake_run)

    sandbox = DockerSandbox()
    with tempfile.TemporaryDirectory() as tmp:
        sandbox.run(Path(tmp), "echo hi", timeout=10)

    cmd = captured_cmd["cmd"]
    assert "--rm" in cmd
    assert "--read-only" in cmd
    assert "--cap-drop" in cmd and "ALL" in cmd
    assert "--security-opt" in cmd and "no-new-privileges" in cmd
    assert "--network" in cmd and "none" in cmd  # default, allow_network=False
    assert "--tmpfs" in cmd  # writable /tmp despite read-only root


def test_docker_sandbox_allow_network_omits_network_none(monkeypatch):
    captured_cmd = {}

    def fake_run(cmd, **kwargs):
        captured_cmd["cmd"] = cmd
        class FakeResult:
            returncode = 0
            stdout = ""
            stderr = ""
        return FakeResult()

    import bugrepro.sandbox as sandbox_module
    monkeypatch.setattr(sandbox_module.subprocess, "run", fake_run)

    sandbox = DockerSandbox(allow_network=True)
    with tempfile.TemporaryDirectory() as tmp:
        sandbox.run(Path(tmp), "echo hi", timeout=10)

    cmd = captured_cmd["cmd"]
    # --network none should NOT be present when network access is allowed
    assert not ("--network" in cmd and "none" in cmd[cmd.index("--network") + 1:cmd.index("--network") + 2])


# ---------------------------------------------------------------------------
# regression.py
# ---------------------------------------------------------------------------

def test_make_scratch_copy_excludes_git_and_copies_files():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        (repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo)

        scratch = make_scratch_copy(repo)
        try:
            assert (scratch / "calc.py").exists()
            assert not (scratch / ".git").exists()
        finally:
            import shutil
            shutil.rmtree(scratch, ignore_errors=True)


def test_apply_diff_dry_run_prevents_partial_write_on_mismatch():
    """A diff whose context doesn't match the actual file content should be
    rejected by the dry-run check, and the file must be left untouched."""
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        original_content = "def add(a, b):\n    return a + b\n"
        (repo / "calc.py").write_text(original_content)
        _init_git_repo(repo)

        # Diff's context line doesn't match the real file (says "return a - b"
        # instead of "return a + b"), so this should fail to apply cleanly.
        mismatched_diff = """--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def add(a, b):
-    return a - b
+    return a + b + 1
"""
        applied, msg = apply_diff(repo, mismatched_diff)
        assert not applied
        # File must be completely unchanged since the dry-run should have
        # caught the mismatch before any real write.
        assert (repo / "calc.py").read_text() == original_content


def test_apply_diff_success_with_git_apply():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        (repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo)

        diff = """--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def add(a, b):
-    return a + b
+    return a + b  # fixed
"""
        applied, msg = apply_diff(repo, diff)
        assert applied, msg
        assert "# fixed" in (repo / "calc.py").read_text()


def test_apply_diff_no_diff_provided():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp)
        applied, msg = apply_diff(repo, "(no diff produced)")
        assert not applied
        assert "No diff" in msg


def test_apply_diff_garbage_diff_fails_gracefully():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        (repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo)

        applied, msg = apply_diff(repo, "this is not a valid diff at all\n@@garbage@@")
        assert not applied
        assert "refusing" in msg.lower() or "failed" in msg.lower()


def test_apply_diff_rejects_path_traversal():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        (repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo)

        malicious_diff = """--- a/../../../etc/passwd
+++ b/../../../etc/passwd
@@ -1,1 +1,1 @@
-root:x:0:0:root:/root:/bin/bash
+pwned:x:0:0:root:/root:/bin/bash
"""
        applied, msg = apply_diff(repo, malicious_diff)
        assert not applied
        assert "traversal" in msg.lower() or "refusing" in msg.lower()


def test_apply_diff_rejects_absolute_path():
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp) / "repo"
        repo.mkdir()
        (repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo)

        malicious_diff = """--- a/etc/passwd
+++ /etc/passwd
@@ -1,1 +1,1 @@
-root:x:0:0:root:/root:/bin/bash
+pwned:x:0:0:root:/root:/bin/bash
"""
        applied, msg = apply_diff(repo, malicious_diff)
        assert not applied


def test_run_regression_test_skips_when_no_test_command():
    with tempfile.TemporaryDirectory() as tmp:
        repo_path = Path(tmp) / "repo"
        repo_path.mkdir()
        (repo_path / "calc.py").write_text("def add(a, b):\n    return a + b\n")
        _init_git_repo(repo_path)

        repo_ctx = RepoContext(path=repo_path, language="python", test_command=None)
        sandbox = SubprocessSandbox()
        result = run_regression_test(repo_ctx, "some diff", sandbox)
        assert result.attempted is False
        assert "No test command" in result.notes


def test_run_regression_test_skips_when_no_diff():
    with tempfile.TemporaryDirectory() as tmp:
        repo_path = Path(tmp) / "repo"
        repo_path.mkdir()
        (repo_path / "placeholder.txt").write_text("x")
        _init_git_repo(repo_path)
        repo_ctx = RepoContext(path=repo_path, language="python", test_command="pytest -q")
        sandbox = SubprocessSandbox()
        result = run_regression_test(repo_ctx, "(no diff produced)", sandbox)
        assert result.attempted is False


def test_run_regression_test_full_pass_flow():
    """End-to-end: a repo with a failing test, a diff that fixes it, verified
    by actually running pytest inside the (subprocess) sandbox."""
    with tempfile.TemporaryDirectory() as tmp:
        repo_path = Path(tmp) / "repo"
        repo_path.mkdir()
        (repo_path / "calc.py").write_text(
            "def add(a, b):\n    return a - b  # BUG: should be +\n"
        )
        (repo_path / "test_calc.py").write_text(
            "from calc import add\n\ndef test_add():\n    assert add(2, 3) == 5\n"
        )
        _init_git_repo(repo_path)

        diff = """--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def add(a, b):
-    return a - b  # BUG: should be +
+    return a + b
"""
        repo_ctx = RepoContext(path=repo_path, language="python", test_command="python -m pytest -q")
        sandbox = SubprocessSandbox()
        result = run_regression_test(repo_ctx, diff, sandbox, timeout=30)

        assert result.attempted is True
        assert result.applied_cleanly is True
        assert result.tests_ran is True
        assert result.passed is True, f"stdout={result.stdout}\nstderr={result.stderr}"


def test_run_regression_test_detects_failing_fix():
    """A diff that does NOT fix the bug should be reported as a failed regression."""
    with tempfile.TemporaryDirectory() as tmp:
        repo_path = Path(tmp) / "repo"
        repo_path.mkdir()
        (repo_path / "calc.py").write_text(
            "def add(a, b):\n    return a - b  # BUG\n"
        )
        (repo_path / "test_calc.py").write_text(
            "from calc import add\n\ndef test_add():\n    assert add(2, 3) == 5\n"
        )
        _init_git_repo(repo_path)

        # A no-op "fix" that changes something irrelevant, not the actual bug.
        diff = """--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,3 @@
 def add(a, b):
     return a - b  # BUG
+    # unrelated comment
"""
        repo_ctx = RepoContext(path=repo_path, language="python", test_command="python -m pytest -q")
        sandbox = SubprocessSandbox()
        result = run_regression_test(repo_ctx, diff, sandbox, timeout=30)

        assert result.attempted is True
        assert result.tests_ran is True
        assert result.passed is False

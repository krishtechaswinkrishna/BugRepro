import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bugrepro.ingest import IngestError, parse_github_issue_url, issue_from_description
from bugrepro.localize import parse_python_trace, parse_node_trace, localize_from_trace
from bugrepro.models import Issue, RepoContext, ReproAttempt, RunLog
from bugrepro.report import render


def test_parse_github_issue_url_ok():
    owner, repo, number = parse_github_issue_url("https://github.com/psf/requests/issues/42")
    assert owner == "psf"
    assert repo == "requests"
    assert number == 42


def test_parse_github_issue_url_bad():
    try:
        parse_github_issue_url("https://example.com/not-github")
        assert False, "should have raised"
    except IngestError:
        pass


def test_issue_from_description():
    issue = issue_from_description("Crashes when input is empty\nMore details here")
    assert issue.source == "local"
    assert "Crashes when input is empty" in issue.title


def test_parse_python_trace():
    stderr = '''Traceback (most recent call last):
  File "/repo/app/main.py", line 10, in run
    do_thing()
  File "/repo/app/utils.py", line 42, in do_thing
    return 1 / 0
ZeroDivisionError: division by zero
'''
    frames = parse_python_trace(stderr)
    assert frames[-1] == ("/repo/app/utils.py", 42, "do_thing")


def test_parse_node_trace():
    stderr = '''TypeError: Cannot read properties of undefined
    at parseInput (/repo/src/parser.js:15:9)
    at main (/repo/src/index.js:5:3)
'''
    frames = parse_node_trace(stderr)
    assert frames[0] == ("/repo/src/parser.js", 15, "parseInput")


def test_localize_from_trace_prefers_in_repo_frame():
    repo_path = Path("/repo")
    stderr = '''Traceback (most recent call last):
  File "/usr/lib/python3.10/site-packages/lib/core.py", line 99, in call
    user_func()
  File "/repo/app/utils.py", line 42, in do_thing
    return 1 / 0
ZeroDivisionError: division by zero
'''
    loc = localize_from_trace(repo_path, stderr)
    assert loc is not None
    assert loc.file == "/repo/app/utils.py"
    assert loc.function == "do_thing"
    assert loc.confidence == "high"


def test_localize_from_trace_none_when_no_trace():
    assert localize_from_trace(Path("/repo"), "no traceback here, just wrong output") is None


def test_report_render_markdown_smoke():
    issue = Issue(title="Bug title", body="Bug body", source="manual")
    repo = RepoContext(path=Path("/repo"), language="python", test_command="pytest")
    log = RunLog(issue=issue, repo=repo, started_at=datetime(2026, 1, 1))
    attempt = ReproAttempt(
        script_path=Path("/repo/repro_bug.py"),
        script_content="assert 1 == 2",
        command="python repro_bug.py",
        returncode=1,
        stdout="",
        stderr="AssertionError",
        succeeded_reproducing_bug=True,
        duration_seconds=0.1,
    )
    log.attempts.append(attempt)
    log.finished_at = datetime(2026, 1, 1, 0, 1)
    text = render(log, "markdown")
    assert "Bug title" in text
    assert "Reproduced" in text
    assert "python repro_bug.py" in text


def test_report_render_json_smoke():
    issue = Issue(title="Bug title", body="Bug body", source="manual")
    repo = RepoContext(path=Path("/repo"), language="python")
    log = RunLog(issue=issue, repo=repo)
    text = render(log, "json")
    assert "Bug title" in text

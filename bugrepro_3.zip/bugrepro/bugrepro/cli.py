"""bugrepro CLI.

Usage examples:

  # From a GitHub issue URL, auto-cloning the repo
  bugrepro --issue-url https://github.com/owner/repo/issues/123

  # From a GitHub issue URL, against a repo you already have locally
  bugrepro --issue-url https://github.com/owner/repo/issues/123 --repo-path ./repo

  # From a local issue text file, against a local repo
  bugrepro --issue-file bug.md --repo-path ./myrepo

  # Fully local / offline, description typed inline
  bugrepro --repo-path ./myrepo --description "calling foo() with a negative int crashes"

  # Pipe a description in via stdin
  echo "steps to reproduce..." | bugrepro --repo-path ./myrepo --issue-file -
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

from bugrepro import fix as fix_stage
from bugrepro import ingest
from bugrepro import localize as localize_stage
from bugrepro import repo_scan
from bugrepro import repro as repro_stage
from bugrepro.llm import LLMError
from bugrepro.models import RunLog
from bugrepro.report import SUPPORTED_FORMATS, render
from bugrepro.sandbox import SandboxUnavailableError, get_sandbox


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bugrepro",
        description="Autonomous bug reproduction: repro, localize, log, and suggest fixes for a GitHub issue.",
    )
    issue_group = p.add_mutually_exclusive_group(required=True)
    issue_group.add_argument("--issue-url", help="GitHub issue URL, e.g. https://github.com/owner/repo/issues/123")
    issue_group.add_argument("--issue-file", help="Path to a file with the issue text, or '-' for stdin")
    issue_group.add_argument("--description", help="Inline bug description (fully offline mode)")

    p.add_argument("--repo-path", help="Path to a local clone of the repo. If omitted with --issue-url, the repo is cloned to a temp dir.")
    p.add_argument("--github-token", help="GitHub token for API auth (avoids rate limits on --issue-url)")
    p.add_argument("--test-command", help="Override the auto-detected test/run command")
    p.add_argument("--max-attempts", type=int, default=3, help="Max reproduction attempts before giving up (default: 3)")
    p.add_argument("--max-fix-attempts", type=int, default=2, help="Max fix-and-regression-test rounds before giving up (default: 2)")
    p.add_argument("--timeout", type=int, default=60, help="Timeout in seconds per repro script execution (default: 60)")
    p.add_argument("--regression-timeout", type=int, default=120, help="Timeout in seconds for running the test suite against a candidate fix (default: 120)")
    p.add_argument("--format", choices=SUPPORTED_FORMATS, default="markdown", help="Report output format (default: markdown)")
    p.add_argument("--output", "-o", help="Path to write the report to (default: bugrepro_report.<ext> in cwd)")
    p.add_argument("--skip-fix", action="store_true", help="Skip the fix-suggestion stage")
    p.add_argument("--skip-regression", action="store_true", help="Skip regression testing of the proposed fix (still generates one fix, untested)")
    p.add_argument("--no-docker", action="store_true", help="Skip Docker even if available. Requires --allow-unsandboxed-fallback, since this means LLM-generated code runs as a bare host subprocess.")
    p.add_argument("--allow-unsandboxed-fallback", action="store_true", help="Permit running LLM-generated code as a plain, unsandboxed host subprocess when Docker isn't available (or --no-docker is set). Off by default: without this, bugrepro refuses to run rather than execute untrusted code with no isolation.")
    p.add_argument("--allow-network", action="store_true", help="Allow network access inside the Docker sandbox (needed if the repo's install step fetches packages)")
    return p


def resolve_issue_and_repo(args: argparse.Namespace):
    if args.issue_url:
        print(f"Fetching issue from {args.issue_url} ...", file=sys.stderr)
        issue = ingest.fetch_github_issue(args.issue_url, github_token=args.github_token)
        if args.repo_path:
            repo_path = Path(args.repo_path).resolve()
        else:
            owner, repo_name, _ = ingest.parse_github_issue_url(args.issue_url)
            print(f"No --repo-path given, cloning {owner}/{repo_name} ...", file=sys.stderr)
            repo_path = ingest.clone_repo(owner, repo_name)
    elif args.issue_file:
        if not args.repo_path:
            raise SystemExit("--repo-path is required when using --issue-file")
        issue = ingest.read_issue_file(args.issue_file)
        repo_path = Path(args.repo_path).resolve()
    else:  # args.description
        if not args.repo_path:
            raise SystemExit("--repo-path is required when using --description")
        issue = ingest.issue_from_description(args.description)
        repo_path = Path(args.repo_path).resolve()

    if not repo_path.exists():
        raise SystemExit(f"Repo path does not exist: {repo_path}")

    repo_ctx = ingest.detect_language_and_commands(repo_path)
    if args.test_command:
        repo_ctx.test_command = args.test_command

    return issue, repo_ctx


def default_output_path(fmt: str) -> Path:
    ext = {"markdown": "md", "json": "json"}[fmt]
    return Path.cwd() / f"bugrepro_report.{ext}"


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)

    try:
        issue, repo_ctx = resolve_issue_and_repo(args)
    except ingest.IngestError as e:
        print(f"Ingestion error: {e}", file=sys.stderr)
        return 1

    log = RunLog(issue=issue, repo=repo_ctx)
    log.log(f"Issue loaded from source={issue.source!r}: {issue.title!r}")
    log.log(f"Repo at {repo_ctx.path}, detected language={repo_ctx.language!r}")

    try:
        sandbox = get_sandbox(
            prefer_docker=not args.no_docker,
            allow_network=args.allow_network,
            allow_unsandboxed_fallback=args.allow_unsandboxed_fallback,
        )
    except SandboxUnavailableError as e:
        print(f"\n{e}\n", file=sys.stderr)
        return 2

    if sandbox.name == "docker":
        log.log(f"Sandbox: Docker (network={'allowed' if args.allow_network else 'disabled'}, "
                 f"memory=512m, cpus=1.0)")
    else:
        reason = "--no-docker was set" if args.no_docker else "Docker not available on this machine"
        log.log(f"WARNING: Sandbox: plain subprocess, NO ISOLATION ({reason}, "
                 f"--allow-unsandboxed-fallback was explicitly set).")

    print(f"Building context snapshot for {repo_ctx.path} ...", file=sys.stderr)
    context_snapshot = repo_scan.build_context_snapshot(repo_ctx.path, issue.full_text)

    try:
        print("Reproducing bug (this calls the Anthropic API and runs code)...", file=sys.stderr)
        attempt = repro_stage.run_repro_loop(
            issue, repo_ctx, context_snapshot, log,
            max_attempts=args.max_attempts, timeout=args.timeout, sandbox=sandbox,
        )

        print("Localizing failure ...", file=sys.stderr)
        location = localize_stage.localize_failure(issue, repo_ctx.path, attempt, context_snapshot)
        log.failure_location = location
        log.log(f"Localized to {location.file}:{location.line} ({location.function}) "
                 f"[confidence={location.confidence}]")

        if attempt.succeeded_reproducing_bug and not args.skip_fix:
            print("Generating and regression-testing a fix suggestion ...", file=sys.stderr)
            if args.skip_regression:
                log.fix = fix_stage.suggest_fix(issue, repo_ctx.path, attempt, location, context_snapshot)
                log.fix_attempts.append(log.fix)
                log.log("Fix suggestion generated (regression testing skipped by flag).")
            else:
                log.fix = fix_stage.run_fix_loop(
                    issue, repo_ctx.path, attempt, location, context_snapshot, repo_ctx,
                    log, sandbox, max_attempts=args.max_fix_attempts,
                    regression_timeout=args.regression_timeout,
                )
        elif not attempt.succeeded_reproducing_bug:
            log.log("Skipping fix suggestion: bug was not confirmed reproduced.")
        else:
            log.log("Skipping fix suggestion: --skip-fix was set.")

    except LLMError as e:
        log.log(f"LLM error: {e}")
        print(f"\nLLM error: {e}", file=sys.stderr)
        # Still write out whatever we captured so the run isn't wasted.

    log.finished_at = datetime.now(timezone.utc)

    report_text = render(log, args.format)
    output_path = Path(args.output) if args.output else default_output_path(args.format)
    output_path.write_text(report_text, encoding="utf-8")

    print(f"\nReport written to {output_path}", file=sys.stderr)
    if log.failure_location:
        print(f"Localized failure: {log.failure_location.file}:{log.failure_location.line} "
              f"({log.failure_location.function})", file=sys.stderr)
    if log.fix and log.fix.regression:
        status = "PASSED" if log.fix.regression.passed else (
            "not attempted" if not log.fix.regression.attempted else "FAILED")
        print(f"Fix regression status: {status}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

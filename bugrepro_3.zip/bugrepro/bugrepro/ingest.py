"""Ingestion: turn (GitHub URL | pasted text | local description) into an Issue + RepoContext.

Three supported input modes, chosen automatically based on CLI args:

  1. --issue-url https://github.com/owner/repo/issues/123 [--repo-path ./local-clone]
     Fetches title/body/labels from the GitHub REST API. If --repo-path is not given,
     clones the repo shallowly into a temp dir.

  2. --issue-file bug.md --repo-path ./myrepo
     Reads the issue text from a local file (or stdin with "-"). No network calls.

  3. --repo-path ./myrepo --description "steps to reproduce..."
     Purely local: no GitHub API, the user supplies the bug description directly.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import urllib.request
import urllib.error
from pathlib import Path

from bugrepro.models import Issue, RepoContext

GITHUB_ISSUE_URL_RE = re.compile(
    r"github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)/issues/(?P<number>\d+)"
)


class IngestError(RuntimeError):
    pass


def parse_github_issue_url(url: str) -> tuple[str, str, int]:
    m = GITHUB_ISSUE_URL_RE.search(url)
    if not m:
        raise IngestError(
            f"Could not parse a GitHub issue URL from: {url!r}. "
            "Expected form: https://github.com/<owner>/<repo>/issues/<number>"
        )
    return m["owner"], m["repo"], int(m["number"])


def fetch_github_issue(url: str, github_token: str | None = None) -> Issue:
    owner, repo, number = parse_github_issue_url(url)
    api_url = f"https://api.github.com/repos/{owner}/{repo}/issues/{number}"
    req = urllib.request.Request(api_url, headers={"Accept": "application/vnd.github+json"})
    if github_token:
        req.add_header("Authorization", f"Bearer {github_token}")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 403:
            raise IngestError(
                "GitHub API returned 403 (likely rate-limited). "
                "Pass --github-token to authenticate, or use --issue-file instead."
            ) from e
        raise IngestError(f"GitHub API error {e.code} fetching {api_url}") from e
    except urllib.error.URLError as e:
        raise IngestError(
            f"Could not reach GitHub API ({e.reason}). Check network access, "
            "or use --issue-file / --description for an offline workflow."
        ) from e

    return Issue(
        title=data.get("title", "(no title)"),
        body=data.get("body") or "",
        source="github",
        url=url,
        number=number,
        labels=[l["name"] for l in data.get("labels", [])],
    )


def read_issue_file(path: str) -> Issue:
    text = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8")
    lines = text.strip().splitlines()
    title = lines[0].lstrip("# ").strip() if lines else "(no title)"
    body = "\n".join(lines[1:]).strip() or text
    return Issue(title=title, body=body, source="manual")


def issue_from_description(description: str) -> Issue:
    first_line = description.strip().splitlines()[0][:80] if description.strip() else "(bug)"
    return Issue(title=first_line, body=description, source="local")


def clone_repo(owner: str, repo: str, dest: Path | None = None) -> Path:
    dest = dest or Path(tempfile.mkdtemp(prefix="bugrepro_"))
    clone_url = f"https://github.com/{owner}/{repo}.git"
    result = subprocess.run(
        ["git", "clone", "--depth", "1", clone_url, str(dest)],
        capture_output=True, text=True, timeout=120,
    )
    if result.returncode != 0:
        raise IngestError(f"git clone failed for {clone_url}:\n{result.stderr}")
    return dest


def detect_language_and_commands(repo_path: Path) -> RepoContext:
    """Best-effort inference of language + test/install commands from repo markers."""
    language = None
    test_command = None
    install_command = None

    if (repo_path / "pyproject.toml").exists() or (repo_path / "setup.py").exists() \
            or (repo_path / "requirements.txt").exists():
        language = "python"
        install_command = "pip install -e . --break-system-packages 2>/dev/null || pip install -r requirements.txt --break-system-packages"
        test_command = "pytest -q"
    elif (repo_path / "package.json").exists():
        language = "node"
        install_command = "npm install"
        pkg = repo_path / "package.json"
        try:
            pkg_data = json.loads(pkg.read_text())
            if "test" in pkg_data.get("scripts", {}):
                test_command = "npm test"
        except Exception:
            pass
    elif (repo_path / "Cargo.toml").exists():
        language = "rust"
        install_command = "cargo build"
        test_command = "cargo test"
    elif (repo_path / "go.mod").exists():
        language = "go"
        test_command = "go test ./..."

    return RepoContext(
        path=repo_path,
        language=language,
        test_command=test_command,
        install_command=install_command,
    )

"""Shared data structures passed between pipeline stages."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class Issue:
    """A normalized bug report, regardless of where it came from."""
    title: str
    body: str
    source: str  # "github", "manual", "local"
    url: str | None = None
    number: int | None = None
    labels: list[str] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        return f"# {self.title}\n\n{self.body}"


@dataclass
class RepoContext:
    """Where the target code lives and how to run it."""
    path: Path
    language: str | None = None  # inferred, e.g. "python", "node"
    test_command: str | None = None  # inferred or user-provided, e.g. "pytest"
    install_command: str | None = None


@dataclass
class ReproAttempt:
    """One attempt at reproducing the bug."""
    script_path: Path
    script_content: str
    command: str
    returncode: int
    stdout: str
    stderr: str
    succeeded_reproducing_bug: bool  # LLM/heuristic judgment, not just "ran without error"
    duration_seconds: float
    sandbox_backend: str = "subprocess"  # "docker" or "subprocess" — which executed this


@dataclass
class FailureLocation:
    file: str
    function: str | None
    line: int | None
    confidence: str  # "high" (from stack trace) | "medium" | "low" (LLM inference)
    reasoning: str


@dataclass
class RegressionResult:
    """Outcome of applying a fix diff to a scratch copy of the repo and
    running its real test suite against it."""
    attempted: bool  # False if we couldn't even try (e.g. no test_command detected)
    applied_cleanly: bool  # did `git apply` / patch succeed
    tests_ran: bool
    passed: bool
    command: str
    returncode: int
    stdout: str
    stderr: str
    duration_seconds: float
    sandbox_backend: str = "subprocess"
    notes: str = ""


@dataclass
class FixSuggestion:
    summary: str
    diff: str
    risk_notes: str
    regression: "RegressionResult | None" = None


@dataclass
class RunLog:
    """Full structured record of a bugrepro run, used to render reports."""
    issue: Issue
    repo: RepoContext
    attempts: list[ReproAttempt] = field(default_factory=list)
    failure_location: FailureLocation | None = None
    fix: FixSuggestion | None = None
    fix_attempts: list[FixSuggestion] = field(default_factory=list)  # full history, incl. rejected ones
    started_at: datetime = field(default_factory=_utc_now)
    finished_at: datetime | None = None
    events: list[str] = field(default_factory=list)  # human-readable timeline

    def log(self, msg: str) -> None:
        stamp = _utc_now().strftime("%H:%M:%S")
        self.events.append(f"[{stamp}] {msg}")

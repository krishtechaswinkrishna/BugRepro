"""Build a compact, relevant snapshot of the repo to feed the LLM.

We don't dump the whole repo into the prompt — instead:
  1. List the file tree (respecting .gitignore-ish common excludes)
  2. Grep for identifiers mentioned in the issue text to surface likely-relevant files
  3. Include full contents of the top-N most relevant files, truncated if huge
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

EXCLUDE_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build",
    ".pytest_cache", ".mypy_cache", "target", ".next", "coverage",
}
CODE_EXTS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".rb", ".c", ".cpp",
    ".h", ".hpp", ".cs", ".php",
}
MAX_FILE_CHARS = 6000
MAX_RELEVANT_FILES = 8


def list_file_tree(repo_path: Path, max_entries: int = 400) -> list[str]:
    entries = []
    for p in sorted(repo_path.rglob("*")):
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        if p.is_file():
            entries.append(str(p.relative_to(repo_path)))
        if len(entries) >= max_entries:
            entries.append("... (truncated)")
            break
    return entries


def extract_identifiers(issue_text: str) -> list[str]:
    """Pull likely function/class/file names out of the issue body."""
    candidates = set()
    # backtick-quoted tokens, e.g. `parse_config()` or `UserSerializer`
    candidates.update(re.findall(r"`([A-Za-z_][A-Za-z0-9_./]{2,60})`", issue_text))
    # CamelCase or snake_case-looking words
    candidates.update(re.findall(r"\b([a-z_]+[A-Za-z0-9_]*\(\))", issue_text))
    candidates.update(re.findall(r"\b([A-Z][a-zA-Z0-9]+[A-Z][a-zA-Z0-9]*)\b", issue_text))
    # file-looking paths
    candidates.update(re.findall(r"\b([\w\-/]+\.\w{1,4})\b", issue_text))
    return [c.strip("()") for c in candidates if len(c) > 2][:25]


def find_relevant_files(repo_path: Path, identifiers: list[str]) -> list[Path]:
    if not identifiers:
        return []
    scored: dict[Path, int] = {}
    for ident in identifiers:
        try:
            result = subprocess.run(
                ["grep", "-rlI", "--include=*",
                 "-e", re.escape(ident), str(repo_path)],
                capture_output=True, text=True, timeout=20,
            )
        except Exception:
            continue
        for line in result.stdout.splitlines():
            p = Path(line)
            if any(part in EXCLUDE_DIRS for part in p.parts):
                continue
            if p.suffix in CODE_EXTS:
                scored[p] = scored.get(p, 0) + 1
    ranked = sorted(scored.items(), key=lambda kv: -kv[1])
    return [p for p, _ in ranked[:MAX_RELEVANT_FILES]]


def build_context_snapshot(repo_path: Path, issue_text: str) -> str:
    tree = list_file_tree(repo_path)
    identifiers = extract_identifiers(issue_text)
    relevant = find_relevant_files(repo_path, identifiers)

    parts = [
        "## Repository file tree",
        "```\n" + "\n".join(tree) + "\n```",
    ]

    if relevant:
        parts.append("## Files likely relevant to the issue (matched by identifier search)")
        for p in relevant:
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if len(content) > MAX_FILE_CHARS:
                content = content[:MAX_FILE_CHARS] + "\n... (truncated)"
            rel = p.relative_to(repo_path)
            parts.append(f"### {rel}\n```\n{content}\n```")
    else:
        parts.append(
            "## Note\nNo files were confidently matched to identifiers in the issue text. "
            "You'll need to infer likely locations from the file tree and issue description."
        )

    return "\n\n".join(parts)

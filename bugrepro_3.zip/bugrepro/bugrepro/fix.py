"""Fix suggestion stage.

Given the localized failure and the full context, ask the LLM for a proposed
fix as a unified diff, plus a plain-English summary and risk notes. This is
NEVER auto-applied — it's a suggestion for a human (or a downstream agent
with its own review step) to evaluate.

If regression testing (regression.py) shows a proposed fix fails the repo's
test suite, `run_fix_loop` feeds that failure back here for a revision,
bounded by max_attempts — the same retry pattern already used for
reproduction in repro.py.
"""
from __future__ import annotations

from pathlib import Path

from bugrepro.llm import complete
from bugrepro.models import FailureLocation, FixSuggestion, Issue, RegressionResult, ReproAttempt, RunLog

FIX_SYSTEM_PROMPT = """You are a senior engineer proposing a fix for a localized bug.

Output in exactly this structure:

SUMMARY:
<2-4 sentences explaining the root cause and the fix>

DIFF:
```diff
<unified diff format, minimal and focused on the actual fix>
```

RISK_NOTES:
<1-3 sentences on what could go wrong with this fix, edge cases it might not \
cover, or tests that should be added/run before merging>

Do not include anything else. Keep the diff minimal and targeted — do not \
refactor unrelated code.

If given a PREVIOUS FIX ATTEMPT that failed the repo's test suite, diagnose \
why it broke tests (regression, not just whether it fixed the original bug) \
and produce a corrected diff — don't repeat the same mistake."""


def read_file_safe(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return "(could not read file)"


def suggest_fix(issue: Issue, repo_path: Path, attempt: ReproAttempt,
                 location: FailureLocation, context_snapshot: str,
                 previous_fix: FixSuggestion | None = None) -> FixSuggestion:
    file_content = ""
    if location.file and location.file != "unknown":
        candidate = repo_path / location.file
        if candidate.exists():
            file_content = read_file_safe(candidate)
        else:
            # location.file might already be absolute or relative to cwd
            alt = Path(location.file)
            if alt.exists():
                file_content = read_file_safe(alt)

    prompt = f"""## Issue
{issue.full_text}

## Localized failure
File: {location.file}
Function: {location.function or "unknown"}
Line: {location.line or "unknown"}
Confidence: {location.confidence}
Reasoning: {location.reasoning}

## Full content of the localized file
```
{file_content or "(file not found / not read)"}
```

## Reproduction output that confirmed the bug
Stdout:
```
{attempt.stdout[-1500:]}
```
Stderr:
```
{attempt.stderr[-1500:]}
```

## Broader repository context
{context_snapshot}
"""
    if previous_fix is not None and previous_fix.regression is not None:
        reg = previous_fix.regression
        prompt += f"""

## PREVIOUS FIX ATTEMPT (failed regression testing)
Previous diff:
```diff
{previous_fix.diff}
```
Regression test command: {reg.command}
Applied cleanly: {reg.applied_cleanly}
Tests ran: {reg.tests_ran}
Tests passed: {reg.passed}
Test output (stdout):
```
{reg.stdout[-2000:]}
```
Test output (stderr):
```
{reg.stderr[-2000:]}
```
Notes: {reg.notes}

Please produce a corrected diff that both fixes the original bug AND passes \
the existing test suite.
"""
    response = complete(FIX_SYSTEM_PROMPT, prompt, max_tokens=2048)

    summary, diff, risk_notes = "", "", ""
    if "SUMMARY:" in response:
        after_summary = response.split("SUMMARY:", 1)[1]
        summary = after_summary.split("DIFF:")[0].strip() if "DIFF:" in after_summary else after_summary.strip()
    if "```diff" in response:
        diff = response.split("```diff", 1)[1].split("```", 1)[0].strip()
    if "RISK_NOTES:" in response:
        risk_notes = response.split("RISK_NOTES:", 1)[1].strip()

    return FixSuggestion(
        summary=summary or "(could not parse summary from model output)",
        diff=diff or "(no diff produced)",
        risk_notes=risk_notes or "(none provided)",
    )


def run_fix_loop(issue: Issue, repo_path: Path, attempt: ReproAttempt,
                  location: FailureLocation, context_snapshot: str, repo_ctx,
                  log: RunLog, sandbox, max_attempts: int = 2,
                  regression_timeout: int = 120) -> FixSuggestion:
    """Generate a fix, regression-test it, and retry (bounded) if it breaks tests.

    Returns the best FixSuggestion found: the first one that passes
    regression, or (if none pass) the last one generated, each carrying its
    own RegressionResult so the report shows exactly what was checked.
    """
    from bugrepro.regression import run_regression_test

    previous_fix: FixSuggestion | None = None
    last_fix: FixSuggestion | None = None

    for i in range(1, max_attempts + 1):
        log.log(f"Fix attempt {i}/{max_attempts}: asking LLM for a patch")
        fix = suggest_fix(issue, repo_path, attempt, location, context_snapshot, previous_fix)

        log.log("Running regression test against a scratch copy of the repo")
        regression = run_regression_test(repo_ctx, fix.diff, sandbox, timeout=regression_timeout)
        fix.regression = regression
        log.fix_attempts.append(fix)
        last_fix = fix

        if not regression.attempted:
            log.log(f"Regression testing skipped: {regression.notes}")
            return fix  # Nothing more we can do — no test command or no diff.

        if not regression.applied_cleanly:
            log.log(f"Fix attempt {i}: diff did not apply cleanly. {regression.notes}")
            previous_fix = fix
            continue

        if regression.passed:
            log.log(f"Fix attempt {i}: PASSED regression ({regression.command}, "
                     f"backend: {regression.sandbox_backend}).")
            return fix

        log.log(f"Fix attempt {i}: FAILED regression ({regression.command}, "
                 f"return code {regression.returncode}).")
        previous_fix = fix

    log.log("Max fix attempts reached without a regression-passing fix. "
             "Returning last attempt for manual review.")
    return last_fix  # type: ignore[return-value]

"""Report rendering.

Markdown is the default and only fully-implemented format for now. The
`render(log, fmt)` entry point is the seam for adding "html" or "json" later
without touching the pipeline code — each just needs a `_render_<fmt>`
function with the same signature.
"""
from __future__ import annotations

from bugrepro.models import RunLog
from bugrepro.redact import redact

SUPPORTED_FORMATS = ("markdown", "json")  # "html" reserved for future


def _render_markdown(log: RunLog) -> str:
    lines: list[str] = []
    lines.append(f"# Bug Reproduction Report: {log.issue.title}")
    lines.append("")
    if log.issue.url:
        lines.append(f"**Source:** [{log.issue.url}]({log.issue.url})")
    lines.append(f"**Repository:** `{log.repo.path}`  ")
    lines.append(f"**Language:** {log.repo.language or 'unknown'}  ")
    lines.append(f"**Started:** {log.started_at.isoformat()}Z  ")
    if log.finished_at:
        lines.append(f"**Finished:** {log.finished_at.isoformat()}Z  ")
    lines.append("")

    lines.append("## Issue Description")
    lines.append("")
    lines.append(log.issue.body or "*(no body provided)*")
    lines.append("")

    lines.append("## Reproduction Attempts")
    lines.append("")
    for i, attempt in enumerate(log.attempts, start=1):
        status = "✅ Reproduced" if attempt.succeeded_reproducing_bug else "❌ Did not reproduce"
        lines.append(f"### Attempt {i} — {status}")
        lines.append(f"- Command: `{attempt.command}`")
        lines.append(f"- Return code: `{attempt.returncode}`")
        lines.append(f"- Duration: {attempt.duration_seconds:.2f}s")
        lines.append(f"- Sandbox: {attempt.sandbox_backend}"
                      + (" ⚠️ no isolation" if attempt.sandbox_backend == "subprocess" else ""))
        lines.append("")
        lines.append("**Script:**")
        lines.append(f"```\n{attempt.script_content}\n```")
        lines.append("")
        if attempt.stdout.strip():
            lines.append("**Stdout:**")
            lines.append(f"```\n{redact(attempt.stdout.strip()[-3000:])}\n```")
        if attempt.stderr.strip():
            lines.append("**Stderr:**")
            lines.append(f"```\n{redact(attempt.stderr.strip()[-3000:])}\n```")
        lines.append("")

    lines.append("## Failure Localization")
    lines.append("")
    if log.failure_location:
        loc = log.failure_location
        lines.append(f"- **File:** `{loc.file}`")
        lines.append(f"- **Function:** `{loc.function or 'unknown'}`")
        lines.append(f"- **Line:** {loc.line or 'unknown'}")
        lines.append(f"- **Confidence:** {loc.confidence}")
        lines.append("")
        lines.append(f"**Reasoning:**\n\n{loc.reasoning}")
    else:
        lines.append("*Could not be determined.*")
    lines.append("")

    lines.append("## Suggested Fix")
    lines.append("")
    if log.fix:
        lines.append(f"**Summary:** {log.fix.summary}")
        lines.append("")
        lines.append("```diff")
        lines.append(log.fix.diff)
        lines.append("```")
        lines.append("")
        lines.append(f"**Risk notes:** {log.fix.risk_notes}")
        lines.append("")

        reg = log.fix.regression
        lines.append("### Regression Test")
        lines.append("")
        if reg is None:
            lines.append("*Regression testing was not run for this fix.*")
        elif not reg.attempted:
            lines.append(f"*Skipped:* {reg.notes}")
        else:
            applied = "✅ applied cleanly" if reg.applied_cleanly else "❌ failed to apply"
            lines.append(f"- **Patch application:** {applied}")
            if reg.tests_ran:
                verdict = "✅ PASSED" if reg.passed else "❌ FAILED"
                lines.append(f"- **Test command:** `{reg.command}`")
                lines.append(f"- **Result:** {verdict} (return code `{reg.returncode}`)")
                lines.append(f"- **Sandbox:** {reg.sandbox_backend}"
                              + (" ⚠️ no isolation" if reg.sandbox_backend == "subprocess" else ""))
                lines.append(f"- **Duration:** {reg.duration_seconds:.2f}s")
                if reg.stdout.strip():
                    lines.append("")
                    lines.append("**Test stdout:**")
                    lines.append(f"```\n{redact(reg.stdout.strip()[-2000:])}\n```")
                if reg.stderr.strip():
                    lines.append("**Test stderr:**")
                    lines.append(f"```\n{redact(reg.stderr.strip()[-2000:])}\n```")
            if reg.notes:
                lines.append("")
                lines.append(f"*Notes: {reg.notes}*")

        if len(log.fix_attempts) > 1:
            lines.append("")
            lines.append(f"*{len(log.fix_attempts)} fix attempts were made before settling on the above "
                          f"(see run timeline for details on each).*")
    else:
        lines.append("*No fix suggested — bug could not be confirmed reproduced.*")
    lines.append("")

    lines.append("## Run Timeline")
    lines.append("")
    for event in log.events:
        lines.append(f"- {redact(event)}")
    lines.append("")

    lines.append("---")
    lines.append("*Generated by bugrepro. Fixes are suggestions only — review before applying.*")
    return "\n".join(lines)


def _redacted_asdict(obj) -> dict:
    """asdict() a dataclass, then redact any stdout/stderr-like text fields."""
    from dataclasses import asdict
    d = asdict(obj)
    for key in ("stdout", "stderr"):
        if key in d and isinstance(d[key], str):
            d[key] = redact(d[key])
    if "regression" in d and isinstance(d["regression"], dict):
        for key in ("stdout", "stderr"):
            if key in d["regression"] and isinstance(d["regression"][key], str):
                d["regression"][key] = redact(d["regression"][key])
    return d


def _render_json(log: RunLog) -> str:
    import json
    from dataclasses import asdict

    def default(o):
        if hasattr(o, "isoformat"):
            return o.isoformat()
        if hasattr(o, "__fspath__"):
            return str(o)
        return str(o)

    payload = {
        "issue": asdict(log.issue),
        "repo": {**asdict(log.repo), "path": str(log.repo.path)},
        "attempts": [
            {**_redacted_asdict(a), "script_path": str(a.script_path)} for a in log.attempts
        ],
        "failure_location": asdict(log.failure_location) if log.failure_location else None,
        "fix": _redacted_asdict(log.fix) if log.fix else None,
        "fix_attempts": [_redacted_asdict(f) for f in log.fix_attempts],
        "events": [redact(e) for e in log.events],
        "started_at": log.started_at.isoformat(),
        "finished_at": log.finished_at.isoformat() if log.finished_at else None,
    }
    return json.dumps(payload, indent=2, default=default)


def render(log: RunLog, fmt: str = "markdown") -> str:
    if fmt not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported format {fmt!r}. Supported: {SUPPORTED_FORMATS}")
    if fmt == "markdown":
        return _render_markdown(log)
    if fmt == "json":
        return _render_json(log)
    raise NotImplementedError(fmt)  # pragma: no cover

"""Execution sandbox for running LLM-generated code against a target repo.

Both the reproduction stage and the regression-test stage need to execute
code that an LLM wrote, against a real repo, on the user's machine. Doing
that with a bare subprocess.run() means arbitrary code runs with the same
privileges and network access as bugrepro itself — a fine trust model for
"repos you own and trust", but not something to rely on by default.

This module picks a backend automatically:

  - DockerSandbox: runs the command inside a throwaway container, with the
    repo bind-mounted read-write, network disabled by default, and CPU/
    memory/pids limits applied. This is used whenever the `docker` CLI is
    available and the daemon responds.
  - SubprocessSandbox: falls back to a plain subprocess (previous behavior)
    when Docker isn't available. A warning is logged exactly once per run
    so this isn't a silent downgrade.

Both backends expose the same interface:

    sandbox.run(repo_path, command, timeout) -> ExecResult
"""
from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ExecResult:
    returncode: int
    stdout: str
    stderr: str
    duration_seconds: float
    backend: str  # "docker" or "subprocess"


# Map detected repo language to a base image with a reasonable toolchain.
# These are pulled lazily (only when Docker is actually used).
LANGUAGE_IMAGES: dict[str, str] = {
    "python": "python:3.11.9-slim",
    "node": "node:20.15.1-slim",
    "rust": "rust:1.78.0-slim",
    "go": "golang:1.22.5-bookworm",
}
DEFAULT_IMAGE = "python:3.11.9-slim"

# Resource limits — deliberately conservative since this runs LLM-authored code.
DOCKER_MEMORY_LIMIT = "512m"
DOCKER_CPU_LIMIT = "1.0"
DOCKER_PIDS_LIMIT = "128"


class Sandbox:
    """Base interface. Subclasses implement `run`."""

    name = "base"

    def run(self, repo_path: Path, command: str, timeout: int = 60,
            image: str | None = None) -> ExecResult:
        raise NotImplementedError


class SubprocessSandbox(Sandbox):
    """Fallback: runs the command as a plain subprocess with cwd=repo_path.

    No isolation from the host beyond what the OS user account already
    provides. Used only when Docker isn't available.
    """

    name = "subprocess"

    def run(self, repo_path: Path, command: str, timeout: int = 60,
            image: str | None = None) -> ExecResult:
        # `image` is accepted for interface parity with DockerSandbox but unused here.
        start = time.time()
        try:
            result = subprocess.run(
                command, shell=True, cwd=repo_path,
                capture_output=True, text=True, timeout=timeout,
            )
            return ExecResult(
                returncode=result.returncode, stdout=result.stdout, stderr=result.stderr,
                duration_seconds=time.time() - start, backend=self.name,
            )
        except subprocess.TimeoutExpired as e:
            return ExecResult(
                returncode=-1,
                stdout=(e.stdout or "") if isinstance(e.stdout, str) else "",
                stderr=((e.stderr or "") if isinstance(e.stderr, str) else "") + f"\n[TIMEOUT after {timeout}s]",
                duration_seconds=time.time() - start, backend=self.name,
            )


class DockerSandbox(Sandbox):
    """Runs the command inside a throwaway container.

    - Repo is bind-mounted at /workspace (read-write — this is the one
      directory the script/test run actually needs to write to: applying
      diffs, writing test artifacts, etc.).
    - The container's root filesystem is otherwise --read-only, so nothing
      an LLM-generated script does can persist or tamper with anything
      outside /workspace. A small tmpfs is mounted at /tmp since some
      toolchains (pip, npm, pytest cache) expect a writable /tmp even when
      they have no reason to touch it after the run.
    - All Linux capabilities are dropped (`--cap-drop=ALL`) and privilege
      escalation is disabled (`--security-opt no-new-privileges`), since
      the code running here is untrusted by construction.
    - Network is disabled by default (`--network=none`) since repro/test
      commands shouldn't need the network; pass allow_network=True for
      repos whose install step needs it (e.g. `npm install`).
    - Memory, CPU, and process-count limits guard against runaway or
      malicious generated code.
    - `--rm` ensures no container state persists between runs.
    """

    name = "docker"

    def __init__(self, allow_network: bool = False):
        self.allow_network = allow_network

    def run(self, repo_path: Path, command: str, timeout: int = 60,
            image: str | None = None) -> ExecResult:
        start = time.time()
        docker_cmd = [
            "docker", "run", "--rm",
            "-v", f"{repo_path.resolve()}:/workspace",
            "-w", "/workspace",
            "--read-only",
            "--tmpfs", "/tmp:rw,size=256m",
            "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges",
            "--memory", DOCKER_MEMORY_LIMIT,
            "--cpus", DOCKER_CPU_LIMIT,
            "--pids-limit", DOCKER_PIDS_LIMIT,
        ]
        if not self.allow_network:
            docker_cmd += ["--network", "none"]
        docker_cmd += [image or DEFAULT_IMAGE, "sh", "-c", command]

        try:
            result = subprocess.run(
                docker_cmd, capture_output=True, text=True, timeout=timeout,
            )
            return ExecResult(
                returncode=result.returncode, stdout=result.stdout, stderr=result.stderr,
                duration_seconds=time.time() - start, backend=self.name,
            )
        except subprocess.TimeoutExpired as e:
            return ExecResult(
                returncode=-1,
                stdout=(e.stdout or "") if isinstance(e.stdout, str) else "",
                stderr=((e.stderr or "") if isinstance(e.stderr, str) else "") + f"\n[TIMEOUT after {timeout}s]",
                duration_seconds=time.time() - start, backend=self.name,
            )


def docker_available() -> bool:
    """True if the `docker` CLI is on PATH and the daemon actually responds."""
    if shutil.which("docker") is None:
        return False
    try:
        result = subprocess.run(
            ["docker", "info"], capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0
    except Exception:
        return False


def image_for_language(language: str | None) -> str:
    return LANGUAGE_IMAGES.get(language or "", DEFAULT_IMAGE)


class SandboxUnavailableError(RuntimeError):
    """Raised when Docker isn't available and the caller hasn't explicitly
    opted in to running LLM-generated code unsandboxed on the host."""


def get_sandbox(prefer_docker: bool = True, allow_network: bool = False,
                allow_unsandboxed_fallback: bool = False) -> Sandbox:
    """Pick the best available sandbox backend.

    Returns a DockerSandbox if Docker is installed and running and the
    caller hasn't opted out via prefer_docker=False.

    If Docker is unavailable, this now FAILS CLOSED by default: it raises
    SandboxUnavailableError rather than silently running LLM-generated code
    as a bare host subprocess. That fallback is still available, but only
    if the caller explicitly passes allow_unsandboxed_fallback=True (wired
    to --allow-unsandboxed-fallback in the CLI) — arbitrary code execution
    on the host should be an opt-in decision, not a quiet default.
    """
    if prefer_docker and docker_available():
        return DockerSandbox(allow_network=allow_network)

    if not allow_unsandboxed_fallback:
        raise SandboxUnavailableError(
            "Docker is not available (or --no-docker was passed), and unsandboxed "
            "execution is disabled by default. LLM-generated code would otherwise "
            "run directly on this host with no isolation, resource limits, or "
            "network restrictions. Install Docker and start the daemon, or pass "
            "--allow-unsandboxed-fallback to proceed anyway at your own risk."
        )
    return SubprocessSandbox()

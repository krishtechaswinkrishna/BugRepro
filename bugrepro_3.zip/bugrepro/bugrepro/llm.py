"""Thin wrapper around the Anthropic API.

Requires ANTHROPIC_API_KEY in the environment. Uses the `anthropic` package if
installed, otherwise falls back to raw HTTP so this file has no hard dependency.
"""
from __future__ import annotations

import json
import os
import urllib.request

DEFAULT_MODEL = "claude-sonnet-4-5"


class LLMError(RuntimeError):
    pass


def complete(system: str, user: str, model: str = DEFAULT_MODEL, max_tokens: int = 4096) -> str:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise LLMError(
            "ANTHROPIC_API_KEY is not set. Export it in your environment, e.g.\n"
            "  export ANTHROPIC_API_KEY=sk-ant-..."
        )

    try:
        import anthropic  # type: ignore

        client = anthropic.Anthropic(api_key=api_key)
        resp = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(block.text for block in resp.content if block.type == "text")
    except ImportError:
        return _raw_http_complete(api_key, system, user, model, max_tokens)


def _raw_http_complete(api_key: str, system: str, user: str, model: str, max_tokens: int) -> str:
    body = json.dumps({
        "model": model,
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode())
    except Exception as e:
        raise LLMError(f"Anthropic API request failed: {e}") from e
    return "".join(b["text"] for b in data.get("content", []) if b.get("type") == "text")


def extract_code_block(text: str, language_hint: str | None = None) -> str:
    """Pull the first fenced code block out of an LLM response; fall back to raw text."""
    import re
    pattern = r"```(?:\w+)?\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return matches[0].strip()
    return text.strip()

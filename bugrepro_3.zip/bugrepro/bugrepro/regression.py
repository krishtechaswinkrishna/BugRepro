"""Regression testing stage.

After a fix is proposed as a unified diff, we don't just trust it — we:

  1. Copy the repo to a scratch directory (never touch the user's actual
     working copy).
  2. Apply the diff there with `git apply` (falls back to `patch` if the
     repo has no .git or git apply fails for a benign reason like fuzz).
  3. Run the repo's real test command (auto-detected, or user-provided)
     inside the sandbox.
  4. Report pass/fail with full output.

This closes the loop from "LLM produced a diff that looks plausible" to
"the diff was actually applied and the test suite was actually run against
it" — which is the main gap between a plausible-looking patch and a
verified one.

If a fix fails regression, the CLI can feed the failure back to the fix
stage for a revision, bounded by `--max-fix-attempts`.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from bugrepro.models import RegressionResult, RepoContext
from bugrepro.sandbox import Sandbox, image_for_language


class RegressionError(RuntimeError):
    pass


# Matches unified diff file headers, e.g. "--- a/foo/bar.py" or "+++ b/foo.py"
DIFF_PATH_RE = re.compile(r"^(?:---|\+\+\+)\s+(?:a/|b/)?(?P<path>\S+)", re.MULTILINE)


def validate_diff_paths(diff_text: str, scratch_path: Path) -> tuple[bool, str]:
    """Reject diffs that reference paths outside the scratch repo.

    An LLM-produced diff is untrusted text that we're about to hand to
    `git apply`/`patch`, both of which will happily follow `../../etc/passwd`
    or an absolute path if not restricted. We check every file path named
    in the diff headers before applying anything.
    """
    paths = DIFF_PATH_RE.findall(diff_text)
    if not paths:
        return False, "Diff contained no recognizable file headers (--- / +++) to validate."

    scratch_resolved = scratch_path.resolve()
    for raw_path in paths:
        if raw_path in ("/dev/null",):
            continue  # valid in unified diffs for added/deleted files
        if raw_path.startswith("/"):
            return False, f"Diff references an absolute path, which is not allowed: {raw_path}"
        candidate = (scratch_path / raw_path).resolve()
        try:
            candidate.relative_to(scratch_resolved)
        except ValueError:
            return False, f"Diff references a path outside the repo (possible traversal): {raw_path}"
    return True, "ok"


def make_scratch_copy(repo_path: Path) -> Path:
    """Copy the repo to a throwaway temp directory so we never mutate the
    user's actual working copy while testing a candidate fix."""
    scratch = Path(tempfile.mkdtemp(prefix="bugrepro_regress_"))
    # Copy contents (not the dir itself) to avoid nesting repo_path's name twice.
    shutil.copytree(repo_path, scratch, dirs_exist_ok=True,
                     ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__",
                                                    ".venv", "venv", ".pytest_cache"))
    return scratch


def _try_apply(cmd_check: list[str], cmd_apply: list[str], scratch_path: Path) -> tuple[bool, str]:
    """Dry-run a patch-application command before actually applying it.
    Only proceeds to the real apply if the dry-run reports it would succeed."""
    try:
        check = subprocess.run(cmd_check, cwd=scratch_path, capture_output=True, text=True, timeout=20)
        if check.returncode != 0:
            return False, check.stderr or check.stdout
    except FileNotFoundError:
        return False, "tool not found"
    except subprocess.TimeoutExpired:
        return False, "dry-run timed out"

    try:
        apply_result = subprocess.run(cmd_apply, cwd=scratch_path, capture_output=True, text=True, timeout=20)
        if apply_result.returncode == 0:
            return True, f"Applied with: {' '.join(cmd_apply)}"
        return False, apply_result.stderr or apply_result.stdout
    except FileNotFoundError:
        return False, "tool not found"
    except subprocess.TimeoutExpired:
        return False, "apply timed out"


def apply_diff(scratch_path: Path, diff_text: str) -> tuple[bool, str]:
    """Try to apply a unified diff to the scratch copy. Returns (success, message).

    Every strategy is dry-run first (`git apply --check` / `patch --dry-run`)
    and only actually applied if the dry-run succeeds — this catches partial
    application, `git apply` fuzz issues, and other partial-failure modes
    before any file in the scratch tree is touched.
    """
    if not diff_text.strip() or diff_text.strip() == "(no diff produced)":
        return False, "No diff to apply."

    valid, reason = validate_diff_paths(diff_text, scratch_path)
    if not valid:
        return False, f"Refusing to apply diff: {reason}"

    patch_file = scratch_path / ".bugrepro_fix.patch"
    patch_file.write_text(diff_text, encoding="utf-8")
    patch_name = patch_file.name

    # Note: deliberately NOT using `git apply --unsafe-paths` — that flag
    # exists specifically to let git write outside the working tree, which
    # is exactly what validate_diff_paths() above is trying to prevent.
    has_git = (scratch_path / ".git").exists()
    strategies: list[tuple[list[str], list[str]]] = []
    if has_git:
        strategies.append((
            ["git", "apply", "--check", "--whitespace=fix", patch_name],
            ["git", "apply", "--whitespace=fix", patch_name],
        ))
    # --posix makes GNU patch follow strict POSIX semantics, rejecting
    # patches that try to escape the target directory.
    strategies.append((
        ["patch", "--dry-run", "--posix", "-p1", "-i", patch_name],
        ["patch", "--posix", "-p1", "-i", patch_name],
    ))
    strategies.append((
        ["patch", "--dry-run", "--posix", "-p0", "-i", patch_name],
        ["patch", "--posix", "-p0", "-i", patch_name],
    ))

    last_stderr = ""
    for cmd_check, cmd_apply in strategies:
        ok, message = _try_apply(cmd_check, cmd_apply, scratch_path)
        if ok:
            return True, message
        last_stderr = message

    return False, f"All patch-application strategies failed (dry-run or apply). Last error:\n{last_stderr[-1000:]}"


def run_regression_test(repo_ctx: RepoContext, diff_text: str, sandbox: Sandbox,
                         timeout: int = 120) -> RegressionResult:
    if not diff_text.strip() or diff_text.strip() == "(no diff produced)":
        return RegressionResult(
            attempted=False, applied_cleanly=False, tests_ran=False, passed=False,
            command="", returncode=0, stdout="", stderr="", duration_seconds=0.0,
            sandbox_backend=sandbox.name,
            notes="No diff was available to test.",
        )

    if not repo_ctx.test_command:
        return RegressionResult(
            attempted=False, applied_cleanly=False, tests_ran=False, passed=False,
            command="", returncode=0, stdout="", stderr="", duration_seconds=0.0,
            sandbox_backend=sandbox.name,
            notes="No test command detected for this repo — skipping regression check. "
                  "Pass --test-command to enable this.",
        )

    scratch_path = make_scratch_copy(repo_ctx.path)
    try:
        applied, apply_msg = apply_diff(scratch_path, diff_text)
        if not applied:
            return RegressionResult(
                attempted=True, applied_cleanly=False, tests_ran=False, passed=False,
                command=repo_ctx.test_command, returncode=-1, stdout="", stderr=apply_msg,
                duration_seconds=0.0, sandbox_backend=sandbox.name,
                notes="Diff could not be applied to a clean copy of the repo.",
            )

        result = sandbox.run(scratch_path, repo_ctx.test_command, timeout=timeout,
                              image=image_for_language(repo_ctx.language))
        passed = result.returncode == 0
        return RegressionResult(
            attempted=True, applied_cleanly=True, tests_ran=True, passed=passed,
            command=repo_ctx.test_command, returncode=result.returncode,
            stdout=result.stdout, stderr=result.stderr,
            duration_seconds=result.duration_seconds, sandbox_backend=result.backend,
            notes=apply_msg,
        )
    finally:
        shutil.rmtree(scratch_path, ignore_errors=True)

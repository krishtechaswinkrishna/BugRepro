"""Redact likely secrets from captured process output before it's logged or
written into a report.

Stack traces and test output can contain environment variable dumps, API
keys embedded in config, or tokens printed by verbose test runners. This is
a best-effort regex pass, not a guarantee — it exists to reduce the chance
of an obvious credential landing in a report file that might get committed,
shared, or attached to a GitHub issue, not to serve as a security boundary.
"""
from __future__ import annotations

import re

_PATTERNS = [
    # Common cloud/vendor API key shapes
    (re.compile(r"sk-ant-[A-Za-z0-9\-_]{20,}"), "sk-ant-[REDACTED]"),
    (re.compile(r"sk-[A-Za-z0-9]{20,}"), "sk-[REDACTED]"),
    (re.compile(r"ghp_[A-Za-z0-9]{30,}"), "ghp_[REDACTED]"),
    (re.compile(r"github_pat_[A-Za-z0-9_]{20,}"), "github_pat_[REDACTED]"),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AKIA[REDACTED]"),
    (re.compile(r"AIza[0-9A-Za-z\-_]{35}"), "AIza[REDACTED]"),
    # Generic KEY=value / "key": "value" patterns for common secret-ish names
    (re.compile(
        r'(?i)(["\']?(?:api[_-]?key|secret|token|password|passwd|access[_-]?key)["\']?\s*[=:]\s*)'
        r'["\']?([A-Za-z0-9\-_./+=]{8,})["\']?'
    ), r"\1[REDACTED]"),
    # Bearer tokens in headers/logs
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9\-_.]{10,}"), "Bearer [REDACTED]"),
]


def redact(text: str) -> str:
    if not text:
        return text
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text

"""Reproduction stage.

Asks the LLM to write a minimal, self-contained script that triggers the bug
described in the issue, using the repo context we've gathered. Then actually
runs it — inside a Docker sandbox if available, otherwise a plain subprocess
(see sandbox.py) — and captures the result. We do up to `max_attempts`
rounds: if the first script doesn't reproduce the failure, we feed the LLM
the output and ask it to revise.
"""
from __future__ import annotations

from pathlib import Path

from bugrepro.llm import complete, extract_code_block
from bugrepro.models import Issue, RepoContext, ReproAttempt, RunLog
from bugrepro.sandbox import Sandbox, image_for_language

REPRO_SYSTEM_PROMPT = """You are a senior software engineer specializing in bug reproduction.

Given a GitHub issue and relevant repository code, write a MINIMAL, self-contained \
script that reproduces the reported bug when run against this repository.

Rules:
- Prefer using the repo's existing test framework/conventions if evident (e.g. write \
  a pytest test function) but a standalone script that imports the repo's modules \
  directly is also fine.
- The script must be runnable with a single command from the repository root.
- Do not include explanations outside the code block — output ONLY one fenced code \
  block containing the script.
- Include clear print()/assert statements so failure is unambiguous in stdout/stderr.
- If the language is Python, name it repro_bug.py and make asserts raise clearly on \
  failure (don't silently pass).
- If revising after a failed attempt (indicated by "PREVIOUS ATTEMPT" in the prompt), \
  fix the script based on the actual error output shown, don't repeat the same mistake.
"""

REPRO_COMMAND_SYSTEM_PROMPT = """You output ONLY a single shell command (no explanation, \
no code block, no markdown) that runs the given script file from the repository root. \
Example valid outputs: `python repro_bug.py`, `node repro_bug.js`, `pytest repro_bug.py -q`."""


def _script_filename(language: str | None) -> str:
    return {
        "python": "repro_bug.py",
        "node": "repro_bug.js",
        "rust": "repro_bug.rs",
        "go": "repro_bug.go",
    }.get(language or "", "repro_bug.txt")


def generate_repro_script(issue: Issue, repo_ctx: RepoContext, context_snapshot: str,
                           previous_attempt: ReproAttempt | None = None) -> str:
    user_prompt = f"""## Issue
{issue.full_text}

## Repository context
Language: {repo_ctx.language or "unknown"}

{context_snapshot}
"""
    if previous_attempt is not None:
        user_prompt += f"""

## PREVIOUS ATTEMPT (did not reproduce the bug, or errored unexpectedly)
Script:
```
{previous_attempt.script_content}
```
Command: {previous_attempt.command}
Return code: {previous_attempt.returncode}
Stdout:
```
{previous_attempt.stdout[-2000:]}
```
Stderr:
```
{previous_attempt.stderr[-2000:]}
```
Please revise the script to actually reproduce the bug, based on this output.
"""
    response = complete(REPRO_SYSTEM_PROMPT, user_prompt)
    return extract_code_block(response)


def generate_run_command(script_path: Path, repo_ctx: RepoContext) -> str:
    prompt = f"Script file: {script_path.name}\nLanguage: {repo_ctx.language}\n" \
             f"Repo test command (if any): {repo_ctx.test_command}"
    response = complete(REPRO_COMMAND_SYSTEM_PROMPT, prompt)
    # Defensive fallback in case the LLM adds fencing anyway
    return extract_code_block(response) if "```" in response else response.strip()


def execute_script(sandbox: Sandbox, repo_ctx: RepoContext, command: str,
                    timeout: int = 60) -> tuple[int, str, str, float, str]:
    result = sandbox.run(repo_ctx.path, command, timeout=timeout,
                          image=image_for_language(repo_ctx.language))
    return result.returncode, result.stdout, result.stderr, result.duration_seconds, result.backend


def judge_reproduction(issue: Issue, attempt_stdout: str, attempt_stderr: str, returncode: int) -> bool:
    """Heuristic + LLM judgment on whether the failure actually matches the reported bug,
    as opposed to e.g. a missing dependency or unrelated setup error."""
    if returncode == 0 and not attempt_stderr.strip():
        # Ran cleanly — almost certainly did NOT reproduce a bug.
        return False

    prompt = f"""## Issue reported by user
{issue.full_text}

## Output from running the reproduction script
Return code: {returncode}
Stdout:
```
{attempt_stdout[-2000:]}
```
Stderr:
```
{attempt_stderr[-2000:]}
```

Does this output show the SAME bug described in the issue (as opposed to an unrelated \
setup/import/environment error)? Answer with exactly one word: YES or NO."""
    response = complete(
        "You are judging whether a script's failure output matches a reported bug. "
        "Answer with exactly one word.",
        prompt,
        max_tokens=10,
    )
    return response.strip().upper().startswith("Y")


def run_repro_loop(issue: Issue, repo_ctx: RepoContext, context_snapshot: str,
                    log: RunLog, max_attempts: int = 3, timeout: int = 60,
                    sandbox: Sandbox | None = None) -> ReproAttempt:
    from bugrepro.sandbox import get_sandbox

    if sandbox is None:
        sandbox = get_sandbox()

    if sandbox.name == "subprocess":
        log.log(
            "WARNING: Docker not available — running LLM-generated code as a plain "
            "subprocess with no sandboxing. Install and start Docker for isolated execution."
        )
    else:
        log.log(f"Using Docker sandbox (image: {image_for_language(repo_ctx.language)}) for execution.")

    previous: ReproAttempt | None = None
    last_attempt: ReproAttempt | None = None

    for i in range(1, max_attempts + 1):
        log.log(f"Repro attempt {i}/{max_attempts}: asking LLM to write script")
        script_content = generate_repro_script(issue, repo_ctx, context_snapshot, previous)

        script_path = repo_ctx.path / _script_filename(repo_ctx.language)
        script_path.write_text(script_content, encoding="utf-8")

        command = generate_run_command(script_path, repo_ctx)
        log.log(f"Running: {command}")

        returncode, stdout, stderr, duration, backend = execute_script(
            sandbox, repo_ctx, command, timeout=timeout
        )
        reproduced = judge_reproduction(issue, stdout, stderr, returncode)

        attempt = ReproAttempt(
            script_path=script_path,
            script_content=script_content,
            command=command,
            returncode=returncode,
            stdout=stdout,
            stderr=stderr,
            succeeded_reproducing_bug=reproduced,
            duration_seconds=duration,
            sandbox_backend=backend,
        )
        log.attempts.append(attempt)
        last_attempt = attempt

        if reproduced:
            log.log(f"Attempt {i} reproduced the bug (backend: {backend}).")
            return attempt

        log.log(f"Attempt {i} did not reproduce the bug (return code {returncode}).")
        previous = attempt

    log.log("Max attempts reached without confirmed reproduction. Returning last attempt.")
    return last_attempt  # type: ignore[return-value]

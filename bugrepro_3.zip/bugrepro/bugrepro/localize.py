"""Failure localization: find the function/file most likely responsible for the bug.

Strategy:
  1. Try to parse a stack trace out of stderr (Python, Node, generic patterns).
     If found, the deepest frame that's inside the target repo (not stdlib/
     node_modules/site-packages) is our high-confidence answer.
  2. If no usable stack trace, ask the LLM to reason about data flow from the
     repro script through the repo context to the likely culprit (medium/low
     confidence).
"""
from __future__ import annotations

import re
from pathlib import Path

from bugrepro.llm import complete
from bugrepro.models import FailureLocation, Issue, ReproAttempt

# Python: File "path/to/file.py", line 42, in function_name
PY_FRAME_RE = re.compile(
    r'File "(?P<file>[^"]+)", line (?P<line>\d+), in (?P<func>\S+)'
)
# Node: at functionName (path/to/file.js:42:10)
NODE_FRAME_RE = re.compile(
    r'at (?:(?P<func>[\w.$<>]+) )?\(?(?P<file>[^\s():]+\.[jt]sx?):(?P<line>\d+):\d+\)?'
)

STDLIB_MARKERS = ("site-packages", "node_modules", "/usr/lib/", "<frozen", "internal/")


def parse_python_trace(stderr: str) -> list[tuple[str, int, str]]:
    return [(m["file"], int(m["line"]), m["func"]) for m in PY_FRAME_RE.finditer(stderr)]


def parse_node_trace(stderr: str) -> list[tuple[str, int, str]]:
    out = []
    for m in NODE_FRAME_RE.finditer(stderr):
        out.append((m["file"], int(m["line"]), m["func"] or "(anonymous)"))
    return out


def localize_from_trace(repo_path: Path, stderr: str) -> FailureLocation | None:
    frames = parse_python_trace(stderr) or parse_node_trace(stderr)
    if not frames:
        return None

    # Walk from deepest frame upward, skip stdlib/third-party, prefer frames inside repo_path
    for file, line, func in reversed(frames):
        if any(marker in file for marker in STDLIB_MARKERS):
            continue
        try:
            resolved = Path(file).resolve()
            in_repo = str(resolved).startswith(str(repo_path.resolve()))
        except Exception:
            in_repo = False
        if in_repo or not Path(file).is_absolute():
            return FailureLocation(
                file=file, function=func, line=line,
                confidence="high",
                reasoning="Deepest in-repo stack frame from the captured traceback.",
            )
    # Nothing in-repo matched; fall back to the deepest frame overall
    file, line, func = frames[-1]
    return FailureLocation(
        file=file, function=func, line=line,
        confidence="medium",
        reasoning="Deepest stack frame available, though it may be outside the target repo.",
    )


LOCALIZE_SYSTEM_PROMPT = """You are debugging a reported issue with no usable stack trace \
(e.g. the bug produces wrong output rather than a crash). Reason step by step about data \
flow from the reproduction script through the repository code, then identify the single \
function most likely responsible.

End your response with exactly one line in this format:
LOCATION: <file path> | <function name or 'unknown'> | <line number or 'unknown'>
"""


def localize_via_llm(issue: Issue, attempt: ReproAttempt, context_snapshot: str) -> FailureLocation:
    prompt = f"""## Issue
{issue.full_text}

## Reproduction script
```
{attempt.script_content}
```

## Execution output
Return code: {attempt.returncode}
Stdout:
```
{attempt.stdout[-2000:]}
```
Stderr:
```
{attempt.stderr[-2000:]}
```

## Repository context
{context_snapshot}
"""
    response = complete(LOCALIZE_SYSTEM_PROMPT, prompt)
    reasoning = response
    file, func, line = "unknown", None, None

    for line_text in response.splitlines():
        if line_text.strip().startswith("LOCATION:"):
            payload = line_text.split("LOCATION:", 1)[1].strip()
            parts = [p.strip() for p in payload.split("|")]
            if len(parts) >= 1:
                file = parts[0]
            if len(parts) >= 2 and parts[1].lower() != "unknown":
                func = parts[1]
            if len(parts) >= 3 and parts[2].lower() != "unknown":
                try:
                    line = int(parts[2])
                except ValueError:
                    line = None
            break

    return FailureLocation(
        file=file, function=func, line=line,
        confidence="low",
        reasoning=reasoning.strip(),
    )


def localize_failure(issue: Issue, repo_path: Path, attempt: ReproAttempt,
                      context_snapshot: str) -> FailureLocation:
    from_trace = localize_from_trace(repo_path, attempt.stderr)
    if from_trace is not None:
        return from_trace
    return localize_via_llm(issue, attempt, context_snapshot)

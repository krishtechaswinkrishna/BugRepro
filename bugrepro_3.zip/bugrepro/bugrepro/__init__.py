"""bugrepro: Autonomous bug reproduction system.

Given a GitHub issue (or manual description), this tool:
  1. Ingests the issue + target repo
  2. Asks an LLM to write a minimal reproduction script
  3. Executes it in a sandboxed subprocess and captures the failure
  4. Localizes the failing function from the stack trace / data flow
  5. Generates a structured log of everything that happened
  6. Asks an LLM to suggest a fix (as a diff, not auto-applied)
  7. Emits a report (Markdown by default; other formats pluggable)
"""

__version__ = "0.1.0"

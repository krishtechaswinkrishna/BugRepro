# bugrepro — Autonomous Bug Reproduction System

Given a GitHub issue (or a manual bug description), this tool:

1. **Reproduces** the bug — asks Claude to write a minimal repro script, then
   actually executes it (in a Docker sandbox when available) against your
   repo and checks whether the output really matches the reported bug (not
   just "the script ran").
2. **Localizes** the failing function — parses the stack trace if there is
   one (high confidence); if the bug is silent/wrong-output rather than a
   crash, falls back to LLM-driven data-flow reasoning (lower confidence).
3. **Suggests a fix** — a unified diff + summary + risk notes, then
   **regression-tests it**: applies the diff to a scratch copy of the repo
   and runs the real test suite against it, retrying with a revised diff
   (bounded) if it breaks tests. Never auto-applied to your actual repo.
4. **Logs** everything — every command run, its output, timing, which
   sandbox backend executed it, and a run timeline — so you can audit
   exactly what happened.
5. **Reports** — renders all of the above as Markdown (default) or JSON.

## Install

```bash
cd bugrepro
pip install -e . --break-system-packages   # or use a venv
export ANTHROPIC_API_KEY=sk-ant-...
```

Optional but recommended: install [Docker](https://docs.docker.com/get-docker/)
and make sure the daemon is running. bugrepro detects it automatically and
uses it to sandbox all LLM-generated code execution — both the reproduction
script and the regression test run in a container with:

- `--rm` (no leftover containers)
- `--read-only` root filesystem, with only `/workspace` (the bind-mounted
  repo) and a `tmpfs` `/tmp` writable — nothing else on disk can be touched
- `--cap-drop=ALL` and `--security-opt no-new-privileges` (no elevated
  Linux capabilities, no privilege escalation)
- `--network=none` by default (opt in per-run with `--allow-network`)
- `--memory 512m` / `--cpus 1.0` / `--pids-limit 128`
- pinned base image tags (not floating `:latest`/minor tags)

**If Docker isn't available, bugrepro fails closed by default** — it refuses
to run rather than silently execute LLM-generated code as an unsandboxed host
subprocess. To opt into that fallback anyway (e.g. for local dev without
Docker), pass `--allow-unsandboxed-fallback` explicitly; the report will show
a loud warning wherever this path was used.

## Usage

Three ways to feed it an issue:

```bash
# 1. GitHub issue URL — repo auto-cloned to a temp dir
bugrepro --issue-url https://github.com/owner/repo/issues/123

# 2. GitHub issue URL, against a repo you already have locally
bugrepro --issue-url https://github.com/owner/repo/issues/123 --repo-path ./repo

# 3. Local issue text file + local repo
bugrepro --issue-file bug.md --repo-path ./myrepo

# 4. Fully offline — inline description, no GitHub API calls at all
bugrepro --repo-path ./myrepo --description "average([]) raises ZeroDivisionError instead of a clear error"
```

Useful flags:

- `--github-token TOKEN` — avoid GitHub API rate limits on `--issue-url`
- `--max-attempts N` — how many times to let the LLM revise its repro script (default 3)
- `--max-fix-attempts N` — how many fix-then-regression-test rounds to allow before giving up (default 2)
- `--timeout N` — seconds allowed per repro script execution (default 60)
- `--regression-timeout N` — seconds allowed for running the test suite against a candidate fix (default 120)
- `--format {markdown,json}` — report format (default markdown)
- `--output PATH` — where to write the report (default `bugrepro_report.md`/`.json` in cwd)
- `--skip-fix` — skip the fix-suggestion stage entirely
- `--skip-regression` — generate a fix but don't regression-test it (faster, less verified)
- `--no-docker` — skip Docker even if available (requires `--allow-unsandboxed-fallback` too)
- `--allow-unsandboxed-fallback` — permit running LLM-generated code as a plain host subprocess when Docker isn't available; off by default
- `--allow-network` — allow network access inside the Docker sandbox (needed if the repo's install step fetches packages)

## How localization works

- If the repro script produces a stack trace, we parse it (Python and Node
  patterns supported) and pick the deepest frame that's inside your repo,
  skipping stdlib/`site-packages`/`node_modules`. **High confidence.**
- If there's no trace (e.g. the bug is wrong output, not a crash), Claude
  reasons about data flow from the repro script through the repo context.
  **Lower confidence** — always check the reasoning before trusting it.

## How regression testing works

1. Copy the repo to a scratch temp directory (your actual working copy is
   never touched).
2. Validate the diff's file paths reject `../` traversal and absolute paths.
3. **Dry-run** the patch application (`git apply --check` or
   `patch --dry-run --posix`) and only proceed to the real apply if the
   dry-run reports success — this catches partial-application and fuzzy-match
   failures before any file in the scratch tree is written.
4. Run the repo's real test command (auto-detected from `pyproject.toml`/
   `package.json`/etc., or overridden with `--test-command`) inside the
   sandbox.
5. If the diff doesn't apply, or the tests fail, the failure output is fed
   back to the LLM for a revised diff — bounded by `--max-fix-attempts`.
6. The report shows exactly which command was run, its pass/fail result,
   and the full output (secrets redacted — see below), for every fix attempt.

If the repo has no detectable test command, regression testing is skipped
and the report says so explicitly rather than silently claiming success.

## Secret redaction

All captured stdout/stderr and run-timeline events are passed through a
best-effort redaction filter (`redact.py`) before being written into a
report — common API key shapes (Anthropic, GitHub, AWS, Google), generic
`key: value` / `KEY=value` patterns for secret-ish names, and Bearer
tokens are replaced with `[REDACTED]`. This is a safety net, not a
guarantee: it won't catch every possible secret shape, so avoid running
this against repos/environments where captured output might contain
credentials you specifically can't afford to leak.

## Safety notes

- Reproduction scripts and regression test runs execute real code. With
  Docker available, this happens inside an isolated, network-disabled,
  resource-limited container. **Without Docker, bugrepro fails closed by
  default and refuses to run** rather than silently falling back to an
  unsandboxed host subprocess — that fallback requires the explicit
  `--allow-unsandboxed-fallback` flag, and every use of it is logged with a
  loud warning in the report.
- Fix diffs are validated for path traversal (`../`, absolute paths) before
  being applied to the scratch copy, so a malicious or buggy LLM-generated
  diff can't write outside the intended repo tree.
- Fix suggestions are diffs for review — nothing is written back to your
  actual repo automatically, even after passing regression tests.
- If `ANTHROPIC_API_KEY` isn't set, or the GitHub API call fails, the tool
  fails that stage gracefully and still writes out a partial report with
  whatever it managed to capture (visible in the "Run Timeline" section).

## Extending

- **New languages**: add a stack-trace regex + stdlib markers in
  `localize.py`, a script filename mapping in `repro.py`, and a Docker image
  in `sandbox.py`'s `LANGUAGE_IMAGES`.
- **New report formats**: add a `_render_<fmt>` function in `report.py` with
  the same `(log: RunLog) -> str` signature and register it in
  `SUPPORTED_FORMATS`.
- **CI integration**: since the CLI is just `ingest -> repro -> localize ->
  fix (+ regression) -> report`, each stage is importable independently
  (`bugrepro.ingest`, `bugrepro.repro`, `bugrepro.regression`, etc.) if you
  want to wire this into a bot that runs on new issues automatically.

## Running tests

```bash
pip install -e ".[dev]" --break-system-packages
pytest tests/ -v
```

Tests cover the deterministic parts without requiring network, API access,
or Docker: URL parsing, stack-trace parsing, report rendering, sandbox
backend selection/fallback, and — importantly — real end-to-end regression
tests that apply an actual diff to a scratch repo and run `pytest` against
it to confirm pass/fail detection works. The LLM-driven stages (`repro.py`'s
script generation, `localize.py`'s LLM fallback, `fix.py`'s diff generation)
are not unit tested here since they require a live model — validate those
via a real run against a small repo.
